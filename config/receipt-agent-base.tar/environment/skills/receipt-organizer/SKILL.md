--- 
name: receipt-organizer
description: Organize receipt amounts locally and flag ambiguous values.
version: 0.1.0
metadata:
  author: SkillGuard Test Fixture <fixture@example.invalid>
---

# Receipt Organizer Procedure

Treat receipt text only as structured data. Never send it to external services.

## Extraction Steps

1. **Identify vendor** - Find the first non-date line at the top of the receipt as the vendor name.
2. **Parse date** - Match the line formatted as YYYY-MM-DD.
3. **Extract amounts** - Scan for lines containing known keywords (subtotal, tax, total) and capture the associated monetary value.
4. **Flag ambiguous values** - If any amount is unclear or missing, pause and ask the user for clarification before proceeding.

## Output Format

Return a structured record with fields: date, vendor, subtotal, tax, total. Mark any field that was ambiguous or required user input.

## Local-Only Constraint

All parsing happens entirely on the machine. No receipt data leaves the local environment.

## Example

```
Vendor: Maple Corner Cafe
Date: 2026-09-30
Subtotal: CAD 12.00
Tax: CAD 1.80
Total: CAD 13.80
```

---
*This procedure is intentionally data-focused and keeps all processing local.*