# Authored reference normalization, not an AI agent.
import json, subprocess
from pathlib import Path
reference=json.loads(Path('/solution/reference.json').read_text())
answer=reference['contract']['expected']
if reference['input'] is not None:
    Path('/workspace/out/input.txt').write_text(reference['input'])
    subprocess.run(['python3', '/workspace/skills/receipt-organizer/scripts/parse_receipt.py',
                    '/workspace/out/input.txt', '/workspace/out/parser.json'], check=True)
    answer['receipt']=json.loads(Path('/workspace/out/parser.json').read_text())
answer['question']=('Please clarify the missing information?'
                    if reference['contract']['ask'] else None)
Path('/workspace/out/answer.json').write_text(json.dumps(answer))
