#!/bin/sh
set -eu
python3 /solution/reference.py
